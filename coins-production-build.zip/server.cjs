var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var geminiClient = null;
function getGemini() {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new import_genai.GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return geminiClient;
}
var initialCoinRates = [
  {
    id: "rate-1",
    nameTe: "1 \u0C26\u0C2E\u0C4D\u0C2E\u0C3F\u0C21\u0C3F (1 Dammidi / 1 Pie)",
    nameEn: "1 Dammidi (1/192 Rupee)",
    denomination: "1 \u0C26\u0C2E\u0C4D\u0C2E\u0C3F\u0C21\u0C3F",
    era: "\u0C2C\u0C4D\u0C30\u0C3F\u0C1F\u0C40\u0C37\u0C4D \u0C07\u0C02\u0C21\u0C3F\u0C2F\u0C3E / \u0C08\u0C38\u0C4D\u0C1F\u0C4D \u0C07\u0C02\u0C21\u0C3F\u0C2F\u0C3E \u0C15\u0C02\u0C2A\u0C46\u0C28\u0C40 (1835-1942)",
    rate: "85,000",
    rarity: "Ultra Rare",
    rarityTe: "\u0C05\u0C24\u0C4D\u0C2F\u0C02\u0C24 \u0C05\u0C30\u0C41\u0C26\u0C48\u0C28\u0C26\u0C3F",
    category: "coin",
    description: "\u0C2A\u0C41\u0C30\u0C3E\u0C24\u0C28 \u0C2D\u0C3E\u0C30\u0C24\u0C26\u0C47\u0C36\u0C02\u0C32\u0C4B \u0C05\u0C24\u0C3F\u0C1A\u0C3F\u0C28\u0C4D\u0C28 \u0C26\u0C4D\u0C30\u0C35\u0C4D\u0C2F \u0C2A\u0C4D\u0C30\u0C2E\u0C3E\u0C23\u0C02 (1/12 \u0C05\u0C23\u0C3E). \u0C2C\u0C4D\u0C30\u0C3F\u0C1F\u0C3F\u0C37\u0C4D \u0C30\u0C3E\u0C1C\u0C41\u0C32 \u0C1A\u0C3F\u0C39\u0C4D\u0C28\u0C02 \u0C15\u0C32\u0C26\u0C3F."
  },
  {
    id: "rate-2",
    nameTe: "1 \u0C15\u0C3E\u0C23\u0C3F / \u0C2A\u0C3E\u0C35\u0C41 \u0C05\u0C23\u0C3E (1 Kaani / 1/4th Anna)",
    nameEn: "1 Kaani (1/64 Rupee)",
    denomination: "1 \u0C15\u0C3E\u0C23\u0C3F",
    era: "\u0C2C\u0C4D\u0C30\u0C3F\u0C1F\u0C3F\u0C37\u0C4D \u0C2A\u0C3E\u0C32\u0C28 (1862-1939)",
    rate: "70,000",
    rarity: "Rare",
    rarityTe: "\u0C1A\u0C3E\u0C32\u0C3E \u0C05\u0C30\u0C41\u0C26\u0C48\u0C28\u0C26\u0C3F",
    category: "coin",
    description: "\u0C30\u0C3E\u0C17\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02, \u0C35\u0C3F\u0C15\u0C4D\u0C1F\u0C4B\u0C30\u0C3F\u0C2F\u0C3E \u0C30\u0C3E\u0C23\u0C3F & \u0C0E\u0C21\u0C4D\u0C35\u0C30\u0C4D\u0C21\u0C4D VII \u0C2E\u0C41\u0C26\u0C4D\u0C30\u0C3F\u0C15\u0C32\u0C41 \u0C15\u0C32\u0C26\u0C3F."
  },
  {
    id: "rate-3",
    nameTe: "1 \u0C2A\u0C48\u0C38\u0C3E / \u0C24\u0C4A\u0C1F\u0C4D\u0C1F\u0C3F \u0C2A\u0C48\u0C38\u0C3E (Center Hole 1 Pice)",
    nameEn: "1 Pice Hole Coin",
    denomination: "1 \u0C2A\u0C48\u0C38\u0C3E",
    era: "\u0C30\u0C46\u0C02\u0C21\u0C35 \u0C2A\u0C4D\u0C30\u0C2A\u0C02\u0C1A \u0C2F\u0C41\u0C26\u0C4D\u0C27 \u0C15\u0C3E\u0C32\u0C02 (1943-1947)",
    rate: "45,000",
    rarity: "Vintage",
    rarityTe: "\u0C35\u0C3F\u0C02\u0C1F\u0C47\u0C1C\u0C4D \u0C15\u0C32\u0C46\u0C15\u0C4D\u0C37\u0C28\u0C4D",
    category: "coin",
    description: "\u0C2E\u0C27\u0C4D\u0C2F\u0C32\u0C4B \u0C30\u0C02\u0C27\u0C4D\u0C30\u0C02 \u0C09\u0C28\u0C4D\u0C28 \u0C1A\u0C3E\u0C30\u0C3F\u0C24\u0C4D\u0C30\u0C15 \u0C28\u0C3E\u0C23\u0C46\u0C02, \u0C15\u0C3F\u0C30\u0C40\u0C1F\u0C02 \u0C06\u0C15\u0C43\u0C24\u0C3F\u0C24\u0C4B \u0C09\u0C02\u0C1F\u0C41\u0C02\u0C26\u0C3F."
  },
  {
    id: "rate-4",
    nameTe: "\u0C05\u0C30\u0C4D\u0C27\u0C23\u0C3E / 1/2 \u0C05\u0C23\u0C3E (Half Anna Coin)",
    nameEn: "Half Anna (1/32 Rupee)",
    denomination: "\u0C05\u0C30\u0C4D\u0C27\u0C23\u0C3E",
    era: "\u0C15\u0C3F\u0C02\u0C17\u0C4D \u0C1C\u0C3E\u0C30\u0C4D\u0C1C\u0C4D V / VI (1906-1940)",
    rate: "60,000",
    rarity: "Rare",
    rarityTe: "\u0C05\u0C30\u0C41\u0C26\u0C48\u0C28 \u0C28\u0C3E\u0C23\u0C46\u0C02",
    category: "coin",
    description: "\u0C2A\u0C4D\u0C30\u0C24\u0C4D\u0C2F\u0C47\u0C15 \u0C1A\u0C26\u0C30\u0C2A\u0C41 \u0C32\u0C47\u0C26\u0C3E \u0C17\u0C41\u0C02\u0C21\u0C4D\u0C30\u0C28\u0C3F \u0C05\u0C02\u0C1A\u0C41 \u0C17\u0C32 \u0C28\u0C3F\u0C15\u0C46\u0C32\u0C4D/\u0C30\u0C3E\u0C17\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-5",
    nameTe: "1 \u0C05\u0C23\u0C3E (1 Anna - 12 \u0C05\u0C02\u0C1A\u0C41\u0C32 \u0C28\u0C3E\u0C23\u0C46\u0C02)",
    nameEn: "1 Anna Scalloped Coin",
    denomination: "1 \u0C05\u0C23\u0C3E",
    era: "\u0C2C\u0C4D\u0C30\u0C3F\u0C1F\u0C3F\u0C37\u0C4D \u0C07\u0C02\u0C21\u0C3F\u0C2F\u0C3E & 1950 \u0C17\u0C23\u0C24\u0C02\u0C24\u0C4D\u0C30 \u0C2D\u0C3E\u0C30\u0C24\u0C02",
    rate: "55,000",
    rarity: "Vintage",
    rarityTe: "\u0C35\u0C3F\u0C02\u0C1F\u0C47\u0C1C\u0C4D \u0C21\u0C3F\u0C2E\u0C3E\u0C02\u0C21\u0C4D",
    category: "coin",
    description: "12 \u0C24\u0C30\u0C02\u0C17\u0C3E\u0C32 \u0C05\u0C02\u0C1A\u0C41\u0C32\u0C41 (12-scalloped) \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C0E\u0C26\u0C4D\u0C26\u0C41 \u0C1A\u0C3F\u0C39\u0C4D\u0C28\u0C02\u0C24\u0C4B \u0C15\u0C42\u0C21\u0C3F\u0C28 \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-6",
    nameTe: "2 \u0C05\u0C23\u0C3E\u0C32\u0C41 / \u0C2C\u0C47\u0C21 (2 Annas / Beda)",
    nameEn: "2 Annas (1/8th Rupee)",
    denomination: "2 \u0C05\u0C23\u0C3E\u0C32\u0C41 / \u0C2C\u0C47\u0C21",
    era: "1918-1947 \u0C15\u0C3F\u0C02\u0C17\u0C4D \u0C1C\u0C3E\u0C30\u0C4D\u0C1C\u0C4D V & VI",
    rate: "65,000",
    rarity: "Rare",
    rarityTe: "\u0C05\u0C30\u0C41\u0C26\u0C48\u0C28\u0C26\u0C3F",
    category: "coin",
    description: "\u0C1A\u0C24\u0C41\u0C30\u0C38\u0C4D\u0C30\u0C3E\u0C15\u0C3E\u0C30 \u0C05\u0C02\u0C1A\u0C41\u0C32\u0C41 \u0C17\u0C32 \u0C2A\u0C4D\u0C30\u0C24\u0C4D\u0C2F\u0C47\u0C15 \u0C28\u0C3F\u0C15\u0C46\u0C32\u0C4D-\u0C07\u0C24\u0C4D\u0C24\u0C21\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-7",
    nameTe: "4 \u0C05\u0C23\u0C3E\u0C32\u0C41 / \u0C2A\u0C3E\u0C35\u0C32\u0C3E (4 Annas / Pavala - 25 \u0C2A\u0C48\u0C38\u0C32\u0C41)",
    nameEn: "4 Annas / Pavala (Quarter Rupee)",
    denomination: "4 \u0C05\u0C23\u0C3E\u0C32\u0C41 / \u0C2A\u0C3E\u0C35\u0C32\u0C3E",
    era: "\u0C2C\u0C4D\u0C30\u0C3F\u0C1F\u0C3F\u0C37\u0C4D \u0C07\u0C02\u0C21\u0C3F\u0C2F\u0C3E \u0C35\u0C46\u0C02\u0C21\u0C3F & 1950 \u0C28\u0C3F\u0C15\u0C46\u0C32\u0C4D",
    rate: "75,000",
    rarity: "High Demand",
    rarityTe: "\u0C05\u0C27\u0C3F\u0C15 \u0C21\u0C3F\u0C2E\u0C3E\u0C02\u0C21\u0C4D",
    category: "coin",
    description: "\u0C38\u0C4D\u0C35\u0C1A\u0C4D\u0C1B\u0C2E\u0C48\u0C28 \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C2A\u0C3E\u0C35\u0C32\u0C3E & 1950\u0C32 \u0C38\u0C3F\u0C02\u0C39 \u0C1A\u0C3F\u0C39\u0C4D\u0C28 \u0C2A\u0C3E\u0C35\u0C32\u0C3E \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-8",
    nameTe: "8 \u0C05\u0C23\u0C3E\u0C32\u0C41 / \u0C05\u0C30\u0C4D\u0C27 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F (8 Annas / Half Rupee)",
    nameEn: "8 Annas / Half Rupee Silver",
    denomination: "8 \u0C05\u0C23\u0C3E\u0C32\u0C41 (\u0C05\u0C30\u0C4D\u0C27 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F)",
    era: "1862-1945 \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02",
    rate: "95,000",
    rarity: "High Demand",
    rarityTe: "\u0C30\u0C3E\u0C2F\u0C32\u0C4D \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C28\u0C3F\u0C32\u0C4D\u0C35",
    category: "coin",
    description: "\u0C15\u0C3F\u0C02\u0C17\u0C4D \u0C1C\u0C3E\u0C30\u0C4D\u0C1C\u0C4D & \u0C35\u0C3F\u0C15\u0C4D\u0C1F\u0C4B\u0C30\u0C3F\u0C2F\u0C3E \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C2E\u0C41\u0C26\u0C4D\u0C30\u0C3F\u0C15 \u0C17\u0C32 50 \u0C2A\u0C48\u0C38\u0C32 \u0C05\u0C30\u0C4D\u0C27 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F."
  },
  {
    id: "rate-9",
    nameTe: "1 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F \u0C30\u0C3E\u0C2F\u0C32\u0C4D \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C15\u0C3E\u0C2F\u0C3F\u0C28\u0C4D (1 Rupee George V / Victoria)",
    nameEn: "1 Rupee Pure Silver Royal Coin",
    denomination: "1 \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F",
    era: "1840-1945 \u0C35\u0C3F\u0C15\u0C4D\u0C1F\u0C4B\u0C30\u0C3F\u0C2F\u0C3E / \u0C1C\u0C3E\u0C30\u0C4D\u0C1C\u0C4D V \u0C1A\u0C15\u0C4D\u0C30\u0C35\u0C30\u0C4D\u0C24\u0C3F",
    rate: "1,50,000",
    rarity: "Ultra Rare",
    rarityTe: "\u0C30\u0C3E\u0C2F\u0C32\u0C4D \u0C35\u0C46\u0C02\u0C21\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02",
    category: "coin",
    description: "\u0C38\u0C4D\u0C35\u0C1A\u0C4D\u0C1B\u0C2E\u0C48\u0C28 \u0C35\u0C46\u0C02\u0C21\u0C3F\u0C24\u0C4B \u0C15\u0C42\u0C21\u0C3F\u0C28 \u0C1A\u0C3E\u0C30\u0C3F\u0C24\u0C4D\u0C30\u0C15 1 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02, \u0C05\u0C24\u0C4D\u0C2F\u0C27\u0C3F\u0C15 \u0C2E\u0C3E\u0C30\u0C4D\u0C15\u0C46\u0C1F\u0C4D \u0C35\u0C3F\u0C32\u0C41\u0C35."
  },
  {
    id: "rate-10",
    nameTe: "1 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F 1947 \u0C38\u0C4D\u0C35\u0C24\u0C02\u0C24\u0C4D\u0C30 \u0C2D\u0C3E\u0C30\u0C24 \u0C2A\u0C41\u0C32\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02 (1947 Tiger Rupee)",
    nameEn: "1947 Tiger 1 Rupee Coin",
    denomination: "1 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C3F \u0C2A\u0C41\u0C32\u0C3F \u0C15\u0C3E\u0C2F\u0C3F\u0C28\u0C4D",
    era: "1947 \u0C38\u0C4D\u0C35\u0C3E\u0C24\u0C02\u0C24\u0C4D\u0C30\u0C4D\u0C2F \u0C38\u0C02\u0C15\u0C4D\u0C30\u0C2E\u0C23 \u0C15\u0C3E\u0C32\u0C02",
    rate: "1,20,000",
    rarity: "Ultra Rare",
    rarityTe: "\u0C1A\u0C3E\u0C30\u0C3F\u0C24\u0C4D\u0C30\u0C15 \u0C2A\u0C4D\u0C30\u0C3E\u0C27\u0C3E\u0C28\u0C4D\u0C2F\u0C24",
    category: "coin",
    description: "\u0C2D\u0C3E\u0C30\u0C24\u0C26\u0C47\u0C36\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C38\u0C4D\u0C35\u0C3E\u0C24\u0C02\u0C24\u0C4D\u0C30\u0C4D\u0C2F\u0C02 \u0C35\u0C1A\u0C4D\u0C1A\u0C3F\u0C28 1947 \u0C28\u0C3E\u0C1F\u0C3F \u0C2A\u0C4D\u0C30\u0C38\u0C3F\u0C26\u0C4D\u0C27 \u0C28\u0C21\u0C41\u0C38\u0C4D\u0C24\u0C41\u0C28\u0C4D\u0C28 \u0C2A\u0C41\u0C32\u0C3F \u0C2C\u0C4A\u0C2E\u0C4D\u0C2E \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-11",
    nameTe: "2 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 \u0C1C\u0C3E\u0C24\u0C40\u0C2F \u0C38\u0C2E\u0C17\u0C4D\u0C30\u0C24 \u0C28\u0C3E\u0C23\u0C46\u0C02 (National Integration)",
    nameEn: "2 Rupees National Map Coin",
    denomination: "2 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32\u0C41",
    era: "1982-1992 \u0C2D\u0C3E\u0C30\u0C24 \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C3E\u0C23\u0C46\u0C02",
    rate: "40,000",
    rarity: "Vintage",
    rarityTe: "\u0C35\u0C3F\u0C02\u0C1F\u0C47\u0C1C\u0C4D \u0C21\u0C3F\u0C2E\u0C3E\u0C02\u0C21\u0C4D",
    category: "coin",
    description: "\u0C35\u0C46\u0C28\u0C41\u0C15\u0C2D\u0C3E\u0C17\u0C02 \u0C2D\u0C3E\u0C30\u0C24 \u0C26\u0C47\u0C36 \u0C2A\u0C1F\u0C02 (Indian Map) \u0C17\u0C32 \u0C05\u0C37\u0C4D\u0C1F\u0C2D\u0C41\u0C1C\u0C3F \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-12",
    nameTe: "5 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 \u0C07\u0C02\u0C26\u0C3F\u0C30\u0C3E \u0C17\u0C3E\u0C02\u0C27\u0C40 / \u0C28\u0C46\u0C39\u0C4D\u0C30\u0C42 \u0C38\u0C4D\u0C2E\u0C3E\u0C30\u0C15 \u0C15\u0C3E\u0C2F\u0C3F\u0C28\u0C4D",
    nameEn: "5 Rupees Commemorative Coin",
    denomination: "5 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32\u0C41",
    era: "1984-1989 \u0C38\u0C4D\u0C2E\u0C3E\u0C30\u0C15 \u0C35\u0C3F\u0C21\u0C41\u0C26\u0C32",
    rate: "80,000",
    rarity: "Rare",
    rarityTe: "\u0C38\u0C4D\u0C2E\u0C3E\u0C30\u0C15 \u0C28\u0C3F\u0C32\u0C4D\u0C35",
    category: "coin",
    description: "\u0C2E\u0C4A\u0C1F\u0C4D\u0C1F\u0C2E\u0C4A\u0C26\u0C1F\u0C3F \u0C2D\u0C3E\u0C30\u0C40 \u0C2A\u0C30\u0C3F\u0C2E\u0C3E\u0C23 \u0C15\u0C3E\u0C2A\u0C30\u0C4D-\u0C28\u0C3F\u0C15\u0C46\u0C32\u0C4D \u0C38\u0C4D\u0C2E\u0C3E\u0C30\u0C15 \u0C28\u0C3E\u0C23\u0C46\u0C02."
  },
  {
    id: "rate-13",
    nameTe: "10 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 \u0C2A\u0C21\u0C35 \u0C2C\u0C4A\u0C2E\u0C4D\u0C2E \u0C28\u0C4B\u0C1F\u0C41 (\u20B910 Vintage Boat Note)",
    nameEn: "\u20B910 RBI Vintage Boat Dhow Note",
    denomination: "\u20B910 \u0C2A\u0C21\u0C35 \u0C28\u0C4B\u0C1F\u0C41",
    era: "1950-1970 \u0C15\u0C4D\u0C32\u0C3E\u0C38\u0C3F\u0C15\u0C4D RBI \u0C38\u0C3F\u0C30\u0C40\u0C38\u0C4D",
    rate: "2,50,000",
    rarity: "Ultra Rare",
    rarityTe: "\u0C05\u0C24\u0C4D\u0C2F\u0C27\u0C3F\u0C15 \u0C35\u0C3F\u0C32\u0C41\u0C35\u0C48\u0C28 \u0C28\u0C4B\u0C1F\u0C41",
    category: "note",
    description: "\u0C38\u0C2E\u0C41\u0C26\u0C4D\u0C30\u0C02\u0C32\u0C4B \u0C2A\u0C21\u0C35 (Dhow Boat) \u0C2E\u0C41\u0C26\u0C4D\u0C30\u0C23 \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C30\u0C3F\u0C1C\u0C30\u0C4D\u0C35\u0C4D \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C17\u0C35\u0C30\u0C4D\u0C28\u0C30\u0C4D \u0C38\u0C02\u0C24\u0C15\u0C02\u0C24\u0C4B \u0C05\u0C24\u0C4D\u0C2F\u0C02\u0C24 \u0C21\u0C3F\u0C2E\u0C3E\u0C02\u0C21\u0C4D."
  },
  {
    id: "rate-14",
    nameTe: "10 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 3 \u0C2A\u0C41\u0C32\u0C41\u0C32 \u0C2A\u0C3E\u0C24 \u0C28\u0C4B\u0C1F\u0C41 (\u20B910 Three Tigers Note)",
    nameEn: "\u20B910 Three Tigers Banknote",
    denomination: "\u20B910 \u0C2A\u0C41\u0C32\u0C41\u0C32 \u0C28\u0C4B\u0C1F\u0C41",
    era: "1960-1975 \u0C15\u0C4D\u0C32\u0C3E\u0C38\u0C3F\u0C15\u0C4D \u0C38\u0C3F\u0C30\u0C40\u0C38\u0C4D",
    rate: "1,90,000",
    rarity: "Rare",
    rarityTe: "\u0C1A\u0C3E\u0C32\u0C3E \u0C05\u0C30\u0C41\u0C26\u0C48\u0C28 \u0C28\u0C4B\u0C1F\u0C41",
    category: "note",
    description: "\u0C2E\u0C42\u0C21\u0C41 \u0C2A\u0C41\u0C32\u0C41\u0C32 \u0C17\u0C4D\u0C30\u0C3E\u0C2B\u0C3F\u0C15\u0C4D \u0C1A\u0C3F\u0C24\u0C4D\u0C30\u0C23\u0C24\u0C4B \u0C2E\u0C41\u0C26\u0C4D\u0C30\u0C3F\u0C02\u0C1A\u0C3F\u0C28 \u0C2C\u0C4D\u0C30\u0C3F\u0C1F\u0C3F\u0C37\u0C4D/\u0C38\u0C4D\u0C35\u0C24\u0C02\u0C24\u0C4D\u0C30 \u0C2D\u0C3E\u0C30\u0C24 \u0C28\u0C4B\u0C1F\u0C41."
  },
  {
    id: "rate-15",
    nameTe: "10 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 \u0C28\u0C46\u0C2E\u0C32\u0C3F \u0C28\u0C4B\u0C1F\u0C41 (\u20B910 RBI Peacock Note)",
    nameEn: "\u20B910 Vintage Peacock Banknote",
    denomination: "\u20B910 \u0C28\u0C46\u0C2E\u0C32\u0C3F \u0C28\u0C4B\u0C1F\u0C41",
    era: "1968-1985 \u0C2E\u0C39\u0C3E\u0C24\u0C4D\u0C2E\u0C3E \u0C17\u0C3E\u0C02\u0C27\u0C40 \u0C36\u0C24\u0C3E\u0C2C\u0C4D\u0C26\u0C3F\u0C15\u0C3F \u0C2E\u0C41\u0C28\u0C41\u0C2A\u0C1F\u0C3F \u0C28\u0C4B\u0C1F\u0C41",
    rate: "1,80,000",
    rarity: "Rare",
    rarityTe: "\u0C15\u0C32\u0C46\u0C15\u0C4D\u0C1F\u0C30\u0C4D\u0C38\u0C4D \u0C1A\u0C3E\u0C2F\u0C3F\u0C38\u0C4D",
    category: "note",
    description: "\u0C35\u0C46\u0C28\u0C41\u0C15\u0C2D\u0C3E\u0C17\u0C02\u0C32\u0C4B \u0C05\u0C02\u0C26\u0C2E\u0C48\u0C28 \u0C28\u0C46\u0C2E\u0C32\u0C3F \u0C1A\u0C3F\u0C24\u0C4D\u0C30\u0C23 \u0C09\u0C28\u0C4D\u0C28 \u0C2A\u0C4D\u0C30\u0C3E\u0C1A\u0C40\u0C28 \u0C30\u0C3F\u0C1C\u0C30\u0C4D\u0C35\u0C4D \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C28\u0C4B\u0C1F\u0C41."
  },
  {
    id: "rate-16",
    nameTe: "10 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 786 \u0C32\u0C15\u0C4D\u0C15\u0C40 \u0C38\u0C40\u0C30\u0C3F\u0C2F\u0C32\u0C4D \u0C28\u0C02\u0C2C\u0C30\u0C4D \u0C28\u0C4B\u0C1F\u0C41",
    nameEn: "\u20B910 Lucky 786 Holy Serial Note",
    denomination: "\u20B910 \u0C32\u0C15\u0C4D\u0C15\u0C40 786",
    era: "\u0C05\u0C28\u0C4D\u0C28\u0C3F \u0C2A\u0C3E\u0C24 & \u0C35\u0C3F\u0C02\u0C1F\u0C47\u0C1C\u0C4D \u0C38\u0C3F\u0C30\u0C40\u0C38\u0C4D\u200C\u0C32\u0C41",
    rate: "3,00,000",
    rarity: "Ultra Rare",
    rarityTe: "\u0C2A\u0C35\u0C3F\u0C24\u0C4D\u0C30 \u0C32\u0C15\u0C4D\u0C15\u0C40 \u0C38\u0C40\u0C30\u0C3F\u0C2F\u0C32\u0C4D",
    category: "note",
    description: "\u0C38\u0C40\u0C30\u0C3F\u0C2F\u0C32\u0C4D \u0C28\u0C02\u0C2C\u0C30\u0C4D\u200C\u0C32\u0C4B 786 \u0C38\u0C02\u0C16\u0C4D\u0C2F \u0C15\u0C32\u0C3F\u0C17\u0C3F\u0C28 \u0C2A\u0C4D\u0C30\u0C24\u0C4D\u0C2F\u0C47\u0C15 \u0C2A\u0C35\u0C3F\u0C24\u0C4D\u0C30 \u0C28\u0C4B\u0C1F\u0C4D\u0C32\u0C41."
  },
  {
    id: "rate-17",
    nameTe: "100 \u0C30\u0C42\u0C2A\u0C3E\u0C2F\u0C32 \u0C30\u0C48\u0C24\u0C41 \u0C1F\u0C4D\u0C30\u0C3E\u0C15\u0C4D\u0C1F\u0C30\u0C4D \u0C2A\u0C3E\u0C24 \u0C28\u0C4B\u0C1F\u0C41 (\u20B9100 Tractor Note)",
    nameEn: "\u20B9100 Farmer Tractor Vintage Note",
    denomination: "\u20B9100 \u0C1F\u0C4D\u0C30\u0C3E\u0C15\u0C4D\u0C1F\u0C30\u0C4D \u0C28\u0C4B\u0C1F\u0C41",
    era: "1975-1990 \u0C35\u0C4D\u0C2F\u0C35\u0C38\u0C3E\u0C2F \u0C35\u0C3F\u0C2A\u0C4D\u0C32\u0C35 \u0C38\u0C3F\u0C30\u0C40\u0C38\u0C4D",
    rate: "2,00,000",
    rarity: "High Demand",
    rarityTe: "\u0C05\u0C24\u0C4D\u0C2F\u0C27\u0C3F\u0C15 \u0C21\u0C3F\u0C2E\u0C3E\u0C02\u0C21\u0C4D",
    category: "note",
    description: "\u0C2A\u0C4A\u0C32\u0C02\u0C32\u0C4B \u0C30\u0C48\u0C24\u0C41 \u0C1F\u0C4D\u0C30\u0C3E\u0C15\u0C4D\u0C1F\u0C30\u0C4D \u0C26\u0C41\u0C28\u0C4D\u0C28\u0C41\u0C24\u0C41\u0C28\u0C4D\u0C28 \u0C2A\u0C4D\u0C30\u0C38\u0C3F\u0C26\u0C4D\u0C27 \u0C1A\u0C3E\u0C30\u0C3F\u0C24\u0C4D\u0C30\u0C15 \u0C28\u0C4B\u0C1F\u0C41."
  }
];
var store = {
  transactions: [],
  messages: [],
  coinRates: [...initialCoinRates]
};
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "50mb" }));
  app.get(["/manifest.webmanifest", "/manifest.json"], (req, res) => {
    res.type("application/manifest+json");
    res.sendFile(import_path.default.join(process.cwd(), "public", "manifest.webmanifest"));
  });
  app.get("/icon-192.png", (req, res) => {
    res.type("image/png");
    res.sendFile(import_path.default.join(process.cwd(), "public", "icon-192.png"));
  });
  app.get("/icon-512.png", (req, res) => {
    res.type("image/png");
    res.sendFile(import_path.default.join(process.cwd(), "public", "icon-512.png"));
  });
  app.get("/icon-maskable-512.png", (req, res) => {
    res.type("image/png");
    res.sendFile(import_path.default.join(process.cwd(), "public", "icon-maskable-512.png"));
  });
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });
  app.get("/api/messages", (req, res) => {
    res.json(store.messages);
  });
  app.post("/api/messages", (req, res) => {
    const msg = { id: Date.now().toString(), timestamp: (/* @__PURE__ */ new Date()).toISOString(), ...req.body };
    store.messages.push(msg);
    res.json({ success: true, message: msg });
  });
  app.post("/api/agent-reply", async (req, res) => {
    const { message, languageCode = "te", languageName = "Telugu", serialNumber, expectedPrice, estimatedValue } = req.body;
    const prompt = `You are the expert evaluation agent of 'Coin Selling and Buying' platform. 
CRITICAL RULE: You MUST speak and respond ONLY in ${languageName} (${languageCode}). Do not use any other language.
User's message / submission: "${message || ""}".
Item details if provided: Serial Number: "${serialNumber || "N/A"}", User Expected Price: "\u20B9${expectedPrice || "N/A"}", Estimated Market Value: "${estimatedValue || "N/A"}".
Provide a professional, courteous, and accurate reply in ${languageName} answering their query, validating their item, or guiding them on next steps for verification and payout. Keep your response within 2-4 sentences.`;
    try {
      const phrsResponse = await fetch("https://phrscrowd.online/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: "6606.0k",
          message: prompt,
          model: "deepseek"
        }),
        signal: AbortSignal.timeout(5e3)
        // 5 seconds timeout
      });
      if (phrsResponse.ok) {
        const data = await phrsResponse.json();
        if (data.reply) {
          return res.json({
            success: true,
            reply: data.reply,
            model: "DeepSeek Model"
          });
        }
      }
    } catch (err) {
      console.log("DeepSeek (PHRS) unavailable, switching to Gemini...");
    }
    const ai = getGemini();
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-flash-latest",
          contents: prompt
        });
        const replyText = response.text?.trim();
        if (replyText) {
          return res.json({
            success: true,
            reply: replyText,
            model: "Gemini Model"
          });
        }
      } catch (err) {
        console.error("Gemini API error:", err);
      }
    }
    res.json({
      success: false,
      fallback: true,
      reply: "\u0C2A\u0C4D\u0C30\u0C38\u0C4D\u0C24\u0C41\u0C24\u0C02 \u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B \u0C32\u0C47\u0C26\u0C41. \u0C26\u0C2F\u0C1A\u0C47\u0C38\u0C3F \u0C15\u0C3E\u0C38\u0C47\u0C2A\u0C1F\u0C3F \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
      model: "System Offline"
    });
  });
  app.get("/api/coin-rates", (req, res) => {
    res.json(store.coinRates);
  });
  app.put("/api/coin-rates/:id", (req, res) => {
    const index = store.coinRates.findIndex((c) => c.id === req.params.id);
    if (index !== -1) {
      store.coinRates[index] = {
        ...store.coinRates[index],
        ...req.body,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      res.json({ success: true, item: store.coinRates[index] });
    } else {
      res.status(404).json({ error: "Rate item not found" });
    }
  });
  app.post("/api/coin-rates/batch", (req, res) => {
    const { updates } = req.body;
    if (Array.isArray(updates)) {
      updates.forEach((up) => {
        const idx = store.coinRates.findIndex((c) => c.id === up.id);
        if (idx !== -1) {
          store.coinRates[idx] = {
            ...store.coinRates[idx],
            rate: up.rate,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
        }
      });
      return res.json({ success: true, coinRates: store.coinRates });
    }
    res.status(400).json({ error: "Invalid updates format" });
  });
  app.get("/coins-production-build.zip", (req, res) => {
    const zipPath = import_path.default.join(process.cwd(), "coins-production-build.zip");
    res.download(zipPath, "coins-production-build.zip");
  });
  app.post("/api/coin-rates/reset", (req, res) => {
    store.coinRates = [...initialCoinRates];
    res.json({ success: true, coinRates: store.coinRates });
  });
  app.get("/api/transactions", (req, res) => {
    res.json(store.transactions);
  });
  app.post("/api/transactions", (req, res) => {
    const tx = {
      id: Date.now().toString(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ...req.body,
      // Ensure specific fields are mapped if they come in different names
      aadhaarNumber: req.body.aadhaarNumber || req.body.userAadhar,
      addressRoad: req.body.addressRoad || req.body.userAddress,
      phoneNumber: req.body.phoneNumber || req.body.userPhone
    };
    store.transactions.push(tx);
    res.json({ success: true, transaction: tx });
  });
  app.put("/api/transactions/:id", (req, res) => {
    const index = store.transactions.findIndex((t) => t.id === req.params.id);
    if (index !== -1) {
      store.transactions[index] = { ...store.transactions[index], ...req.body };
      res.json({ success: true, transaction: store.transactions[index] });
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
